﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Media.Animation;

namespace PennstateUIV2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        

        //Title panel background
        private GradientStopCollection titlePanelBackgroundStops = new GradientStopCollection(2);
        LinearGradientBrush titlePanelBackground;
        List<Button> menuButtonList = new List<Button>();

        //grdVideoContainer background
        private GradientStopCollection videoContainerBgStops = new GradientStopCollection(3);
        LinearGradientBrush videoContainerGradient;

        public MainWindow()
        {
            InitializeComponent();

            //txtBatteryPercentage.Text = System.Windows.SystemParameters.PrimaryScreenWidth.ToString();
            //txtRPM.Text = System.Windows.SystemParameters.PrimaryScreenHeight.ToString();

            SetWindowWidthUsingPrimaryScreenSize(200,100);

            //Title panel Background
            InitializeTopPanel();

            //GrdVideoContainer background
            InitializeVideoContainer();

            //grdContentContainer width set to 0
            InitializeContentContainer();

            //Initializes menu buttons
            InitializeMenuButtons();



            mediaVideo.Position = TimeSpan.FromSeconds(50);
            frmMain.Width = mediaVideo.Width;
            mediaVideo.Play();
            LoadingBarAnimation();

            menuButtonList.Add(btnSendCoordinates);
            menuButtonList.Add(btnReturnToBase);
            menuButtonList.Add(btnTurnOffVideo);
            menuButtonList.Add(btnTurnOffVideo_Copy);

            AnimateMenuButtonsWidth(menuButtonList, TimeSpan.FromSeconds(0.1), TimeSpan.FromSeconds(0.05), 0, false);

        }

        private void SetWindowWidthUsingPrimaryScreenSize(double widthOffset, double heightOffset)
        {
            double primaryScreenWidth = System.Windows.SystemParameters.PrimaryScreenWidth;
            double primaryScreenHeight = System.Windows.SystemParameters.PrimaryScreenHeight;

            if (primaryScreenWidth - widthOffset > 0)
            {
                this.Width = primaryScreenWidth - widthOffset;
            }
            else
            {
                this.Width = 200;
            }
            if (primaryScreenHeight - heightOffset > 0)
            {
                this.Height = primaryScreenHeight - heightOffset;

            }
            else
            {
                this.Height = 100;
            }         
        }

        private void InitializeMenuButtons()
        {
            btnSendCoordinates.Width = 0;
            btnReturnToBase.Width = 0;
            btnTurnOffVideo.Width = 0;
        }

        private void LoadingBarAnimation()
        {
            TranslateTransform trans = new TranslateTransform();
            grdLoadingUnderBar.RenderTransform = trans;

            this.RegisterName("trans", trans);

            DoubleAnimationUsingKeyFrames BobBar = new DoubleAnimationUsingKeyFrames();
            //BobBar.Duration = TimeSpan.FromSeconds(2);
            grdLoadingUnderBar.Opacity = 0.8;
            txtLoading.Opacity = 0.8;

            BobBar.KeyFrames.Add(new LinearDoubleKeyFrame(-5, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(0.5))));
            BobBar.KeyFrames.Add(new LinearDoubleKeyFrame(60, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(1))));
            BobBar.KeyFrames.Add(new LinearDoubleKeyFrame(-60, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(1.5))));
            BobBar.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(2))));
            BobBar.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(2.1))));
            BobBar.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(2.5))));
            BobBar.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(4))));

            BobBar.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(3))));


            BobBar.AutoReverse = false;
            BobBar.RepeatBehavior = RepeatBehavior.Forever;
            Storyboard.SetTargetName(BobBar, "trans");
            Storyboard.SetTargetProperty(BobBar, new PropertyPath(TranslateTransform.XProperty));
            Storyboard sb = new Storyboard();
            sb.Children.Add(BobBar);

            // Start the storyboard after the Grid loads. (Causes exception without this)
            grdLoadingUnderBar.Loaded += delegate (object sender, RoutedEventArgs e)
            {
                sb.Begin(this);
            };


        }

        #region Initializations
        private void InitializeContentContainer()
        {
            grdContentContainer.Width = 20;
        }

        private void InitializeTopPanel()
        {
            GradientStop titleBGLeftColour = new GradientStop(ColourHelper.topBanner, 0.58);
            GradientStop titleBGRightColour = new GradientStop(((SolidColorBrush)(new BrushConverter().ConvertFrom("#FFFB2953"))).Color, 1);
            titlePanelBackgroundStops.Add(titleBGLeftColour);
            titlePanelBackgroundStops.Add(titleBGRightColour);
            titlePanelBackground = new LinearGradientBrush(titlePanelBackgroundStops);
        }

        private void InitializeVideoContainer()
        {

            videoContainerBgStops.Add(new GradientStop(ColourHelper.sunriseOrange, 0.5));
            videoContainerBgStops.Add(new GradientStop(ColourHelper.teal, 1));
            videoContainerGradient = new LinearGradientBrush(videoContainerBgStops, 45);
            grdVideoHolder.Background = videoContainerGradient;

            Storyboard sb = new Storyboard();
            this.RegisterName("videoMidStop", videoContainerBgStops[1]);
            this.RegisterName("videoLeftStop", videoContainerBgStops[0]);

            ColorAnimation colorAnimation = new ColorAnimation();
            colorAnimation.From = ColourHelper.sunriseOrange;
            colorAnimation.To = ColourHelper.skyeBlueForAnimation;

            colorAnimation.Duration = TimeSpan.FromSeconds(9);
            colorAnimation.AutoReverse = true;
            colorAnimation.RepeatBehavior = RepeatBehavior.Forever;
            Storyboard.SetTargetName(colorAnimation, "videoLeftStop");
            Storyboard.SetTargetProperty(colorAnimation,
                new PropertyPath(GradientStop.ColorProperty));
            sb.Children.Add(colorAnimation);


            ColorAnimation colorAnimationMid = new ColorAnimation();
            colorAnimationMid.From = ColourHelper.teal;
            colorAnimationMid.To = ColourHelper.CrimsonForAnimation;
            colorAnimationMid.Duration = TimeSpan.FromSeconds(7);
            colorAnimationMid.AutoReverse = true;
            colorAnimationMid.RepeatBehavior = RepeatBehavior.Forever;
            Storyboard.SetTargetName(colorAnimationMid, "videoMidStop");
            Storyboard.SetTargetProperty(colorAnimationMid,
                new PropertyPath(GradientStop.ColorProperty));
            sb.Children.Add(colorAnimationMid);


            sb.Begin(this);
        }

        #endregion

        #region frmMain events
        private void frmMain_Loaded(object sender, RoutedEventArgs e)
        {
            frmMain_SizeChanged(null, null);
        }
        private void frmMain_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = Mouse.GetPosition(this);



        }
        private void frmMain_SizeChanged(object sender, SizeChangedEventArgs e)
        {

            //Positioning
            ElementPositioningHelper posHelper = new ElementPositioningHelper(this);
            //posHelper.AlignElementToRight(pnlTitleBar, grdPnlTopControlContainer, -8);
            posHelper.AlignElementToLeft(frmMain, grdVideoHolder, grdContentContainer.ActualWidth);
            posHelper.AlignElementToTop(grdVideoHolder, pnlTitleBar.ActualHeight);
            posHelper.AlignElementToLeft(frmMain, grdVideoHolder, grdContentContainer.Margin.Left - grdContentContainer.ActualWidth);


            //sizing
            ElementSizingHelper sizeHelper = new ElementSizingHelper();
            sizeHelper.FillElementHorizontally(pnlTitleBar, this.frmMain, -5);
            sizeHelper.FillElementVertically(grdContentContainer, frmMain, pnlTitleBar.ActualHeight);
            sizeHelper.FillElementHorizontally(grdVideoHolder, frmMain, (grdContentContainer.Margin.Left - grdContentContainer.ActualWidth) + 10, HorizontalAlignment.Left);
            sizeHelper.FillElementVertically(grdVideoHolder, frmMain, pnlTitleBar.ActualHeight + 10, VerticalAlignment.Top);
            sizeHelper.FillElementHorizontally(grdMid, frmMain);
            sizeHelper.FillElementHorizontally(mediaVideo, grdVideoHolder);
            sizeHelper.FillElementVertically(mediaVideo, grdVideoHolder);

        }

        #endregion


        private void SetTopPanelColour()
        {
            RotateTransform rot = new RotateTransform();
            rot.Angle = 38;
            rot.CenterX = 0.5;
            rot.CenterY = 0.5;
            TransformGroup transGroup = new TransformGroup();
            transGroup.Children.Add(rot);

            titlePanelBackground.RelativeTransform = transGroup;

            pnlTitleBar.Background = titlePanelBackground;
        }

        private void ResetTopPanelColour()
        {
            titlePanelBackground.GradientStops[0].Color = ColourHelper.topBanner;
            titlePanelBackground.GradientStops[1].Color = ColourHelper.topBanner;

            SetTopPanelColour();
        }



        #region Top title bar events

        #region pnlTitleBar events
        private void pnlTitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Point mousePos = Mouse.GetPosition(this);
            if (mousePos.X < pnlTitleBar.Width - grdPnlTopControlContainer.Width-grdPnlTopControlContainer.Margin.Left)
            {
                try
                {
                    App.Current.MainWindow.DragMove();
                }
                catch (Exception)
                {


                }
            }
        }

        #endregion

        #region btnExitCross events
        private void btnExitCross_Click_1(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
        private void btnExitCross_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }
        private void btnExitCross_MouseLeave(object sender, MouseEventArgs e)
        {
            ResetTopPanelColour();
            btnExitCross.Background = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0));
        }
        private void button_MouseEnter(object sender, MouseEventArgs e)
        {
            titlePanelBackground.GradientStops[0].Color = ColourHelper.topBanner;
            titlePanelBackground.GradientStops[1].Color = ColourHelper.crimson;
            SetTopPanelColour();
        }
        private void btnExitCross_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            btnExitCross.Background = new SolidColorBrush(Color.FromArgb(50, 0, 0, 0));

        }

        #endregion

        #region minimize_Maximize_png events
        private void minimize_Maximize_png_MouseEnter(object sender, MouseEventArgs e)
        {
            titlePanelBackground.GradientStops[0].Color = ColourHelper.topBanner;
            titlePanelBackground.GradientStops[1].Color = ColourHelper.skyeBlue;
            SetTopPanelColour();
        }

        private void minimize_Maximize_png_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (App.Current.MainWindow.WindowState != WindowState.Maximized)
            {
                App.Current.MainWindow.WindowState = WindowState.Maximized;
            }
            else
            {

                if (App.Current.MainWindow.WindowState == WindowState.Maximized)
                {
                    App.Current.MainWindow.WindowState = WindowState.Normal;
                }
            }
            frmMain_SizeChanged(null, null);

        }

        private void minimize_Maximize_png_MouseLeave(object sender, MouseEventArgs e)
        {
            ResetTopPanelColour();
            MinimizeMaximizeContainer.Background = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0));
        }

        private void minimize_Maximize_png_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            MinimizeMaximizeContainer.Background = new SolidColorBrush(Color.FromArgb(50, 0, 0, 0));
        }
        #endregion


        #region btnMinimize events
        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            App.Current.MainWindow.WindowState = WindowState.Minimized;
        }

        private void btnMinimize_MouseEnter(object sender, MouseEventArgs e)
        {
            titlePanelBackground.GradientStops[0].Color = ColourHelper.topBanner;
            titlePanelBackground.GradientStops[1].Color = ColourHelper.babyBlue;
            SetTopPanelColour();
        }

        private void btnMinimize_MouseLeave(object sender, MouseEventArgs e)
        {
            ResetTopPanelColour();
            btnMinimize.Background = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0));

        }

        private void btnMinimize_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            btnMinimize.Background = new SolidColorBrush(Color.FromArgb(50, 0, 0, 0));

        }

        #endregion

        #endregion


        #region ContentContainer events and functions & grdVideoHolderMovements and sizing

        private void grdOpenSlider_MouseUp(object sender, MouseButtonEventArgs e)
        {
            OpenCloseGridContentSlider();
        }

        bool isGrdContentContainerOpen = false;
        private void OpenCloseGridContentSlider()
        {
            if (isGrdContentContainerOpen == false)
            {
                //Slide out size change for grdContentContainer
                DoubleAnimationUsingKeyFrames slideOutMenu = new DoubleAnimationUsingKeyFrames();
                slideOutMenu.KeyFrames.Add(new LinearDoubleKeyFrame(-10, TimeSpan.FromSeconds(0.2)));
                slideOutMenu.KeyFrames.Add(new LinearDoubleKeyFrame(199, TimeSpan.FromSeconds(0.3)));
                slideOutMenu.Duration = new Duration(TimeSpan.FromSeconds(0.3));

                Storyboard sb = new Storyboard();
                sb.Children.Add(slideOutMenu);
                Storyboard.SetTarget(slideOutMenu, grdContentContainer);
                Storyboard.SetTargetName(slideOutMenu, grdContentContainer.Name);
                Storyboard.SetTargetProperty(slideOutMenu, new PropertyPath(Grid.WidthProperty));



                //Size change for grdVideoHolder to fit grdContentContainer new size
                DoubleAnimationUsingKeyFrames slideVideoHolderSizing = new DoubleAnimationUsingKeyFrames();
                slideVideoHolderSizing.KeyFrames.Add(new LinearDoubleKeyFrame(grdVideoHolder.ActualWidth + 15, TimeSpan.FromSeconds(0.2)));
                slideVideoHolderSizing.KeyFrames.Add(new LinearDoubleKeyFrame(grdVideoHolder.ActualWidth - 214, TimeSpan.FromSeconds(0.3)));
                slideVideoHolderSizing.Duration = new Duration(TimeSpan.FromSeconds(0.3));


                //Moving the grdVideoHolder along with grdContentSliding out
                TranslateTransform animatedTranslateTransform = new TranslateTransform();
                DoubleAnimation moveVideoHolder = new DoubleAnimation(214, TimeSpan.FromSeconds(0.3));
                grdVideoHolder.RenderTransform = animatedTranslateTransform;
                moveVideoHolder.BeginTime = TimeSpan.FromSeconds(0.2);
                animatedTranslateTransform.BeginAnimation(TranslateTransform.XProperty, moveVideoHolder);
                //grdVideoHolder.Width += 199;



                ElementSizingHelper sizeHelper = new ElementSizingHelper();
                //sizeHelper.FillElementHorizontally(btnSendCoordinates, grdContentContainer, -199);
                sizeHelper.FillElementHorizontally(btnReturnToBase, grdContentContainer, 0);
                //sizeHelper.FillElementHorizontally(btnTurnOffVideo, grdContentContainer, -199);
                sizeHelper.FillElementHorizontally(btnTurnOffVideo_Copy, grdContentContainer, 0);



                //Menu button width animations
                AnimateMenuButtonsWidth(menuButtonList, TimeSpan.FromSeconds(0.1), TimeSpan.FromSeconds(0.2), 199, true);


                sb.Begin();
                isGrdContentContainerOpen = true;
            }
            else
            {

                DoubleAnimationUsingKeyFrames slideInMenu = new DoubleAnimationUsingKeyFrames();
                slideInMenu.KeyFrames.Add(new LinearDoubleKeyFrame(230, TimeSpan.FromSeconds(0.1)));
                slideInMenu.KeyFrames.Add(new LinearDoubleKeyFrame(20, TimeSpan.FromSeconds(0.2)));
                slideInMenu.Duration = new Duration(TimeSpan.FromSeconds(0.3));

                Storyboard sb = new Storyboard();
                sb.Children.Add(slideInMenu);
                Storyboard.SetTarget(slideInMenu, grdContentContainer);
                Storyboard.SetTargetName(slideInMenu, grdContentContainer.Name);
                Storyboard.SetTargetProperty(slideInMenu, new PropertyPath(Grid.WidthProperty));

                TranslateTransform animatedTranslateTransform = new TranslateTransform();
                DoubleAnimation moveVideoHolder = new DoubleAnimation(grdVideoHolder.Margin.Left + 199, 0, TimeSpan.FromSeconds(0.2));
                grdVideoHolder.RenderTransform = animatedTranslateTransform;
                animatedTranslateTransform.BeginAnimation(TranslateTransform.XProperty, moveVideoHolder);

                //Menu button width animations
                AnimateMenuButtonsWidth(menuButtonList, TimeSpan.FromSeconds(0.05), TimeSpan.FromSeconds(0.05), 0, false);


                sb.Begin();
                isGrdContentContainerOpen = false;
            }
        }

        private void AnimateMenuButtonsWidth(List<Button> buttonList, TimeSpan timePerButton, TimeSpan delay, double width, bool isOpening)
        {
            int count = 1;
            double delaytime;
            foreach (Button button in buttonList)
            {
                DoubleAnimation buttonWidthAnimation = new DoubleAnimation(width, TimeSpan.FromSeconds(0.1));
                if (isOpening)
                {
                    delaytime = count * delay.Milliseconds / buttonList.Count + 300;
                }
                else
                {
                    delaytime = count * delay.Milliseconds / buttonList.Count;
                }
                buttonWidthAnimation.BeginTime = TimeSpan.FromMilliseconds(delaytime);
                button.BeginAnimation(Button.WidthProperty, buttonWidthAnimation);
                count++;
            }


        }

        #endregion



        bool isVideoPlaying = true;
        private void btnTurnOffVideo_Click(object sender, RoutedEventArgs e)
        {
            if (isVideoPlaying == true)
            {
                btnTurnOffVideo.Content = "Start video stream";
                txtRPM.Visibility = Visibility.Hidden;
                txtBatteryPercentage.Visibility = Visibility.Hidden;
                mediaVideo.Stop();
                mediaVideo.Opacity = 0;
                isVideoPlaying = false;
                txtLoading.Text = "Video stream stopped";
            }
            else
            {
                btnTurnOffVideo.Content = "Stop video stream";
                txtRPM.Visibility = Visibility.Visible;
                txtBatteryPercentage.Visibility = Visibility.Visible;
                mediaVideo.Play();
                mediaVideo.Opacity = 1;
                isVideoPlaying = true;
                txtLoading.Text = "Loading...";
            }
        }

        private void mediaVideo_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (isGrdContentContainerOpen)
            {
                OpenCloseGridContentSlider();
            }
        }
    }
}
