﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;

namespace PennstateUIV2
{
    public class ElementSizingHelper
    {
        public ElementSizingHelper()
        {

        }
        #region Vertical Fill
        public void FillElementVertically(Grid workingElement, Grid parent, double topOffset = 0)
        {
            if (parent.ActualHeight - topOffset > 0)
            {
                workingElement.Height = parent.Height - topOffset;
                workingElement.VerticalAlignment = VerticalAlignment.Bottom; 
            }
        }

        public void FillElementVertically(Grid workingElement, Window parent, double topOffset = 0, VerticalAlignment alignment = VerticalAlignment.Bottom)
        {
            if (parent.ActualHeight - topOffset >0)
            {
                workingElement.Height = parent.ActualHeight - topOffset;
                workingElement.VerticalAlignment = alignment; 
            }
        }

        public void FillElementVertically(MediaElement workingElement, Grid parent, double topOffset = 0)
        {
            if (parent.ActualHeight - topOffset > 0)
            {
                workingElement.Height = parent.Height - topOffset;
                workingElement.VerticalAlignment = VerticalAlignment.Bottom;
            }
        }
        #endregion

        #region Horizontal Fill
        public void FillElementHorizontally(Grid workingElement, Window parent, double leftOffset = 0, HorizontalAlignment alignment = HorizontalAlignment.Left)
        {
            if (parent.ActualWidth - leftOffset > 0)
            {
                workingElement.Width = parent.ActualWidth - leftOffset;
                workingElement.HorizontalAlignment = alignment;
            }
        }

        public void FillElementHorizontally(Grid workingElement, MediaElement parent, double leftOffset = 0, HorizontalAlignment alignment = HorizontalAlignment.Left)
        {
            if (parent.ActualWidth - leftOffset > 0)
            {
                workingElement.Width = parent.ActualWidth - leftOffset;
                workingElement.HorizontalAlignment = alignment;
            }
        }

        public void FillElementHorizontally(MediaElement workingElement, Window parent, double leftOffset = 0, HorizontalAlignment alignment = HorizontalAlignment.Left)
        {
            if (parent.ActualWidth - leftOffset > 0)
            {
                workingElement.Width = parent.ActualWidth - leftOffset;
                workingElement.HorizontalAlignment = alignment;
            }
        }

        public void FillElementHorizontally(MediaElement workingElement, Grid parent, double leftOffset = 0, HorizontalAlignment alignment = HorizontalAlignment.Left)
        {
            if (parent.ActualWidth - leftOffset > 0)
            {
                workingElement.Width = parent.ActualWidth - leftOffset;
                workingElement.HorizontalAlignment = alignment;
            }
        }

        public void FillElementHorizontally(Button workingElement, Grid parent, double leftOffset = 0, HorizontalAlignment alignment = HorizontalAlignment.Left)
        {
            if (parent.ActualWidth - leftOffset > 0)
            {
                workingElement.Width = parent.ActualWidth - leftOffset;
                workingElement.HorizontalAlignment = alignment;
            }
        }


        #endregion
    }
}
