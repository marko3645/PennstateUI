﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace PennstateUIV2
{
    public static class ColourHelper
    {


        public static Color crimson = ((SolidColorBrush)(new BrushConverter().ConvertFrom("#FFFB2953"))).Color;
        public static Color skyeBlue = Color.FromArgb(255, 93, 177, 237);
        public static Color babyBlue = Color.FromArgb(255, 120, 207, 255);

        public static Color topBanner = Color.FromArgb(255, 104, 118, 138);

        public static Color teal = (((SolidColorBrush)(new BrushConverter().ConvertFrom("#881BF5BA")))).Color;
        public static Color sunriseOrange = ((SolidColorBrush)(new BrushConverter().ConvertFrom("#88FF6133"))).Color;
        public static Color skyeBlueForAnimation = Color.FromArgb(127, 93, 177, 237);
        public static Color CrimsonForAnimation = ((SolidColorBrush)(new BrushConverter().ConvertFrom("#88FB2953"))).Color;


    }
}
