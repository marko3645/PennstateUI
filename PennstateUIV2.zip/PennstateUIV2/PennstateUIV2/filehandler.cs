﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PennstateUIV2
{
    public class filehandler
    {
        StreamReader reader;
        StreamWriter writer;
        string filepath;

        public filehandler(string _filepath)
        {
            this.filepath = _filepath;
            
        }

        public List<string> readFrom()
        {
            return new StreamReader(new FileStream(this.filepath, FileMode.Open, FileAccess.Read)).ReadToEnd().Split('\n').ToList().Select(x => x).ToList();
            
        }
        public void writeTo(List<string> data)
        {
            FileStream stream = new FileStream(this.filepath, FileMode.Append, FileAccess.ReadWrite);
            this.writer = new StreamWriter(stream);
            foreach (string item in data)
            {
                writer.WriteLine(item);
            }
            writer.Close();
        }
    }

}
