﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace PennstateUIV2
{
     public class ElementPositioningHelper
    {
        private Window workingWindow;

        public Window WorkingWindow
        {
            get { return workingWindow; }
            set { workingWindow = value; }
        }

        
        public ElementPositioningHelper(Window _workingWindow)
        {
            this.WorkingWindow = _workingWindow;
        }

        #region Element alignments


        #region Align to right
        public void AlignElementToRight(StackPanel workingElement, double offset)
        {
            double leftMargin = this.WorkingWindow.Width - workingElement.ActualWidth + offset;
            workingElement.Margin = new Thickness(leftMargin, workingElement.Margin.Top, workingElement.Margin.Right, workingElement.Margin.Bottom);
        }

        public void AlignElementToRight(Button workingElement, double offset)
        {
            double leftMargin = this.WorkingWindow.Width - workingElement.ActualWidth + offset;
            workingElement.Margin = new Thickness(leftMargin, workingElement.Margin.Top, workingElement.Margin.Right, workingElement.Margin.Bottom);
        }


        public void AlignElementToRight(Grid directParent,Button workingElement, double offset)
        {
            double leftMargin = directParent.ActualWidth - workingElement.ActualWidth + offset;
            workingElement.Margin = new Thickness(leftMargin, workingElement.Margin.Top, workingElement.Margin.Right, workingElement.Margin.Bottom);
        }
        public void AlignElementToRight(Grid directParent, Grid workingElement, double offset)
        {
            double leftMargin = directParent.ActualWidth - workingElement.ActualWidth + offset;
            workingElement.Margin = new Thickness(leftMargin, workingElement.Margin.Top, workingElement.Margin.Right, workingElement.Margin.Bottom);
        }
        #endregion

        #region Align to left

        public void AlignElementToLeft(Grid directParent, Grid workingElement, double offset)
        {
            double leftMargin = directParent.ActualWidth - workingElement.ActualWidth + offset;
            workingElement.Margin = new Thickness(leftMargin, workingElement.Margin.Top, workingElement.Margin.Right, workingElement.Margin.Bottom);
        }

        public void AlignElementToLeft(Window directParent, Grid workingElement, double offset)
        {
            workingElement.Margin = new Thickness(offset, workingElement.Margin.Top, workingElement.Margin.Right, workingElement.Margin.Bottom);
        }


        #endregion

        #region Align to Top

        public void AlignElementToTop(Grid workingElement, double offset)
        {
            workingElement.Margin = new Thickness(workingElement.Margin.Left, offset, workingElement.Margin.Right, workingElement.Margin.Bottom);
        }

        #endregion

        #endregion




    }
}
